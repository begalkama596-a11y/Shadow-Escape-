package com.alkama.shadowescape;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

public class MainActivity extends Activity {
    // Google-provided TEST ad unit IDs. Do not replace these with live IDs during testing.
    private static final String TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712";
    private static final String TEST_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917";

    private WebView web;
    private InterstitialAd interstitialAd;
    private RewardedAd rewardedAd;
    private boolean adsReady = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setTheme(R.style.GameTheme);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#05060F"));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setHapticFeedbackEnabled(false);
        web.setLongClickable(false);
        web.setOnLongClickListener(v -> true);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        web.addJavascriptInterface(new AdsBridge(), "AndroidAds");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return true;
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        hideBars();

        MobileAds.initialize(this, initializationStatus -> runOnUiThread(() -> {
            adsReady = true;
            loadRewardedAd();
            loadInterstitialAd();
        }));
    }

    private class AdsBridge {
        @JavascriptInterface
        public void showRewarded() {
            runOnUiThread(() -> {
                if (rewardedAd == null) {
                    toast("Reward ad is not ready yet. Please try again shortly.");
                    loadRewardedAd();
                    return;
                }
                RewardedAd ad = rewardedAd;
                rewardedAd = null;
                ad.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override public void onAdDismissedFullScreenContent() { loadRewardedAd(); }
                    @Override public void onAdFailedToShowFullScreenContent(AdError error) {
                        loadRewardedAd();
                        toast("Ad could not be shown. Please try again.");
                    }
                });
                ad.show(MainActivity.this, rewardItem -> runOnUiThread(() -> {
                    if (web != null) web.evaluateJavascript("window.onRewardEarned && window.onRewardEarned()", null);
                }));
            });
        }

        @JavascriptInterface
        public void showInterstitial() {
            runOnUiThread(() -> {
                if (interstitialAd == null) {
                    loadInterstitialAd();
                    return;
                }
                InterstitialAd ad = interstitialAd;
                interstitialAd = null;
                ad.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override public void onAdDismissedFullScreenContent() { loadInterstitialAd(); }
                    @Override public void onAdFailedToShowFullScreenContent(AdError error) { loadInterstitialAd(); }
                });
                ad.show(MainActivity.this);
            });
        }
    }

    private void loadRewardedAd() {
        if (isFinishing()) return;
        RewardedAd.load(this, TEST_REWARDED_ID, new AdRequest.Builder().build(),
            new RewardedAdLoadCallback() {
                @Override public void onAdLoaded(RewardedAd ad) { rewardedAd = ad; }
                @Override public void onAdFailedToLoad(LoadAdError error) { rewardedAd = null; }
            });
    }

    private void loadInterstitialAd() {
        if (isFinishing()) return;
        InterstitialAd.load(this, TEST_INTERSTITIAL_ID, new AdRequest.Builder().build(),
            new InterstitialAdLoadCallback() {
                @Override public void onAdLoaded(InterstitialAd ad) { interstitialAd = ad; }
                @Override public void onAdFailedToLoad(LoadAdError error) { interstitialAd = null; }
            });
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) hideBars();
    }

    @Override protected void onPause() {
        super.onPause();
        if (web != null) { web.onPause(); web.pauseTimers(); }
    }

    @Override protected void onResume() {
        super.onResume();
        if (web != null) { web.onResume(); web.resumeTimers(); }
        hideBars();
    }

    @Override public void onBackPressed() { finish(); }

    @Override protected void onDestroy() {
        if (web != null) { web.removeJavascriptInterface("AndroidAds"); web.destroy(); web = null; }
        super.onDestroy();
    }
}
