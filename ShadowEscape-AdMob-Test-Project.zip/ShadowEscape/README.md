# Shadow Escape

Android WebView platform game. This version includes Google Mobile Ads SDK integration using Google's official TEST app/ad unit IDs only.

- Rewarded test ad: shown from the Game Over screen; a completed reward grants one extra life.
- Interstitial test ad: requested after every second level transition.
- These are test ads and do not generate revenue. Do not click ads or replace test IDs with live IDs during development.
- Before release, the parent/guardian managing the developer account must review Google Play and AdMob policies, app content/age rating, consent/privacy requirements, store listing and app readiness.

Build debug APK: `gradle assembleDebug`
